import { useEffect, useState } from "react";
import { ActivityIndicator, Image, Linking, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { router, useLocalSearchParams } from "expo-router";
import { getBook } from "../../src/api";
import type { Book } from "../../src/types";
import { colors } from "../../src/theme";

export default function BookDetail() {
  const { id } = useLocalSearchParams<{id:string}>();
  const [book,setBook]=useState<Book|null>(null);
  const [error,setError]=useState("");
  useEffect(()=>{ if(id) getBook(id).then(setBook).catch(e=>setError(e.message)); },[id]);
  if(!book) return <View style={s.center}>{error?<Text>{error}</Text>:<ActivityIndicator color={colors.gold}/>}</View>;
  const doc=book.media.find(m=>m.kind==="document");
  return <ScrollView style={s.root} contentContainerStyle={s.content}>
    <Pressable onPress={()=>router.back()} style={s.back}><Ionicons name="arrow-forward" size={28} color={colors.ink}/></Pressable>
    <View style={s.hero}>{book.cover_url?<Image source={{uri:book.cover_url}} style={StyleSheet.absoluteFill} resizeMode="cover"/>:<><Text style={s.brand}>L A T I F</Text><Text style={s.heroTitle}>{book.title}</Text></>}</View>
    <Text style={s.title}>{book.title}</Text>
    {!!book.author&&<Text style={s.author}>{book.author}</Text>}
    <View style={s.actions}>
      {book.audio_available&&<Pressable style={s.primary} onPress={()=>router.push(`/player/${book.id}`)}><Ionicons name="headset" size={21} color={colors.white}/><Text style={s.primaryText}>استمع للكتاب</Text></Pressable>}
      {doc&&<Pressable style={s.secondary} onPress={()=>Linking.openURL(doc.url)}><Ionicons name="book" size={21} color={colors.gold}/><Text style={s.secondaryText}>اقرأ النسخة</Text></Pressable>}
    </View>
    <Text style={s.meta}>{book.media.filter(m=>m.kind==="audio").length} ملف صوتي · {book.media.filter(m=>m.kind==="document").length} نسخة قراءة</Text>
    {!!book.description&&<Text style={s.desc}>{book.description}</Text>}
  </ScrollView>;
}
const s=StyleSheet.create({root:{flex:1,backgroundColor:colors.bg},content:{padding:24,paddingTop:58,paddingBottom:80},center:{flex:1,alignItems:"center",justifyContent:"center",backgroundColor:colors.bg},back:{alignSelf:"flex-start",width:52,height:52,borderRadius:26,backgroundColor:"#EEE6DB",alignItems:"center",justifyContent:"center"},hero:{height:390,width:"72%",alignSelf:"center",borderRadius:10,backgroundColor:colors.dark,marginTop:28,padding:22,justifyContent:"space-between",overflow:"hidden"},brand:{color:colors.goldSoft,letterSpacing:5,fontWeight:"700"},heroTitle:{textAlign:"right",fontSize:28,lineHeight:41,fontWeight:"800",color:"#FFF8EF"},title:{fontSize:31,fontWeight:"900",textAlign:"right",color:colors.ink,marginTop:28},author:{textAlign:"right",color:colors.muted,fontSize:16,marginTop:8},actions:{marginTop:28,gap:11},primary:{height:56,borderRadius:28,backgroundColor:colors.dark,flexDirection:"row-reverse",alignItems:"center",justifyContent:"center",gap:9},primaryText:{color:colors.white,fontWeight:"800",fontSize:16},secondary:{height:56,borderRadius:28,borderWidth:1,borderColor:colors.gold,flexDirection:"row-reverse",alignItems:"center",justifyContent:"center",gap:9},secondaryText:{color:colors.gold,fontWeight:"800",fontSize:16},meta:{textAlign:"right",color:colors.muted,marginTop:22},desc:{textAlign:"right",fontSize:16,lineHeight:29,color:colors.ink,marginTop:22}});
