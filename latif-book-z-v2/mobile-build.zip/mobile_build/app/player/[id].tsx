import { useEffect, useMemo, useRef, useState } from "react";
import { ActivityIndicator, Pressable, StyleSheet, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { router, useLocalSearchParams } from "expo-router";
import { setAudioModeAsync, useAudioPlayer, useAudioPlayerStatus } from "expo-audio";
import { getBook, getProgress, saveProgress } from "../../src/api";
import type { Book, MediaItem } from "../../src/types";
import { colors } from "../../src/theme";

function fmt(value:number){ if(!Number.isFinite(value)) return "0:00"; const m=Math.floor(value/60),s=Math.floor(value%60); return `${m}:${String(s).padStart(2,"0")}`; }

export default function Player() {
  const {id}=useLocalSearchParams<{id:string}>();
  const [book,setBook]=useState<Book|null>(null);
  const [trackIndex,setTrackIndex]=useState(0);
  const [restored,setRestored]=useState(false);
  const lastSaved=useRef(0);
  const tracks=useMemo(()=>book?.media.filter(m=>m.kind==="audio")||[],[book]);
  const track:MediaItem|undefined=tracks[trackIndex];
  const player=useAudioPlayer(track?.url || null,{updateInterval:1000});
  const status=useAudioPlayerStatus(player);

  useEffect(()=>{ if(id) getBook(id).then(setBook); },[id]);
  useEffect(()=>{ (async()=>{ await setAudioModeAsync({shouldPlayInBackground:true,playsInSilentMode:true,interruptionMode:"doNotMix"}); })(); },[]);
  useEffect(()=>{ if(!book||!track) return; player.setActiveForLockScreen(true,{title:book.title,artist:book.author||"LATIF"},{showSeekBackward:true,showSeekForward:true}); return ()=>player.clearLockScreenControls(); },[book,track,player]);
  useEffect(()=>{ if(!id||!track||restored) return; (async()=>{ try{const p=await getProgress(id); if(p.media_id===track.id&&p.position_seconds>0) await player.seekTo(p.position_seconds);}finally{setRestored(true)}})(); },[id,track,player,restored]);
  useEffect(()=>{ if(!id||!track||!status.isLoaded) return; const now=Math.floor(status.currentTime); if(now-lastSaved.current>=10){lastSaved.current=now; saveProgress(id,track.id,status.currentTime).catch(()=>{});} },[id,track,status.currentTime,status.isLoaded]);
  useEffect(()=>{ if(status.didJustFinish&&trackIndex<tracks.length-1){setRestored(false);setTrackIndex(i=>i+1);} },[status.didJustFinish,trackIndex,tracks.length]);

  if(!book||!track) return <View style={s.center}>{book?<Text style={s.error}>لا يوجد ملف صوتي مرتبط بهذا الكتاب.</Text>:<ActivityIndicator color={colors.gold}/>}</View>;
  const progress=status.duration>0?Math.min(1,status.currentTime/status.duration):0;
  return <View style={s.root}>
    <Pressable onPress={()=>router.back()} style={s.back}><Ionicons name="chevron-down" size={31} color={colors.ink}/></Pressable>
    <View style={s.cover}><Text style={s.brand}>L A T I F</Text><Text style={s.coverTitle}>{book.title}</Text></View>
    <Text numberOfLines={2} style={s.title}>{book.title}</Text>
    <Text style={s.track}>{track.file_name} · {trackIndex+1}/{tracks.length}</Text>
    <View style={s.bar}><View style={[s.fill,{width:`${progress*100}%`}]} /></View>
    <View style={s.times}><Text>{fmt(status.currentTime)}</Text><Text>{fmt(status.duration)}</Text></View>
    <View style={s.controls}>
      <Pressable onPress={()=>player.seekTo(Math.max(0,status.currentTime-15))}><Ionicons name="play-back" size={34} color={colors.ink}/></Pressable>
      <Pressable style={s.play} onPress={()=>status.playing?player.pause():player.play()}><Ionicons name={status.playing?"pause":"play"} size={38} color={colors.white}/></Pressable>
      <Pressable onPress={()=>player.seekTo(Math.min(status.duration||status.currentTime+30,status.currentTime+15))}><Ionicons name="play-forward" size={34} color={colors.ink}/></Pressable>
    </View>
    <View style={s.nav}><Pressable disabled={trackIndex===0} onPress={()=>{setRestored(false);setTrackIndex(i=>Math.max(0,i-1))}}><Text style={[s.navText,trackIndex===0&&s.disabled]}>السابق</Text></Pressable><Pressable disabled={trackIndex>=tracks.length-1} onPress={()=>{setRestored(false);setTrackIndex(i=>Math.min(tracks.length-1,i+1))}}><Text style={[s.navText,trackIndex>=tracks.length-1&&s.disabled]}>التالي</Text></Pressable></View>
  </View>;
}
const s=StyleSheet.create({root:{flex:1,backgroundColor:colors.bg,padding:25,paddingTop:58},center:{flex:1,alignItems:"center",justifyContent:"center",backgroundColor:colors.bg},error:{color:colors.muted},back:{alignSelf:"flex-start",width:52,height:52,borderRadius:26,backgroundColor:"#EEE6DB",alignItems:"center",justifyContent:"center"},cover:{height:330,width:"70%",alignSelf:"center",backgroundColor:colors.dark,borderRadius:12,marginTop:34,padding:22,justifyContent:"space-between",borderWidth:1,borderColor:"#9A7850"},brand:{color:colors.goldSoft,letterSpacing:5,fontWeight:"700"},coverTitle:{textAlign:"right",fontSize:27,lineHeight:39,fontWeight:"850",color:"#FFF8EF"},title:{textAlign:"center",fontSize:25,fontWeight:"900",color:colors.ink,marginTop:30},track:{textAlign:"center",color:colors.muted,marginTop:8},bar:{height:5,borderRadius:4,backgroundColor:"#D7CCBF",marginTop:29,overflow:"hidden"},fill:{height:"100%",backgroundColor:colors.gold},times:{flexDirection:"row",justifyContent:"space-between",marginTop:8},controls:{flexDirection:"row",justifyContent:"center",alignItems:"center",gap:37,marginTop:25},play:{width:74,height:74,borderRadius:37,backgroundColor:colors.dark,alignItems:"center",justifyContent:"center"},nav:{flexDirection:"row",justifyContent:"space-between",marginTop:28},navText:{color:colors.gold,fontWeight:"800",fontSize:16},disabled:{opacity:.3}});
