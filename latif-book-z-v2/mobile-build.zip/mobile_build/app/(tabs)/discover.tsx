import { useCallback, useEffect, useMemo, useState } from "react";
import { ActivityIndicator, FlatList, Image, Pressable, RefreshControl, StyleSheet, Text, TextInput, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { listBooks } from "../../src/api";
import type { Book } from "../../src/types";
import { colors } from "../../src/theme";

type Filter = "all" | "audio" | "read";

function BookCard({ book }: { book: Book }) {
  return (
    <Pressable style={s.cardWrap} onPress={() => router.push(`/book/${book.id}`)}>
      <View style={s.cover}>
        {book.cover_url ? <Image source={{ uri: book.cover_url }} style={StyleSheet.absoluteFill} resizeMode="cover" /> : (
          <>
            <Text style={s.brand}>L A T I F</Text>
            <View style={s.circle} />
            <Text numberOfLines={4} style={s.coverTitle}>{book.title}</Text>
            <Text style={s.coverFoot}>مجموعة لطيف</Text>
          </>
        )}
      </View>
      <Text numberOfLines={2} style={s.bookTitle}>{book.title}</Text>
      <View style={s.badges}>
        {book.audio_available && <View style={s.badge}><Ionicons name="headset" color={colors.gold} size={15}/><Text style={s.badgeText}>صوت</Text></View>}
        {book.reading_available && <View style={s.badge}><Ionicons name="book" color={colors.gold} size={15}/><Text style={s.badgeText}>قراءة</Text></View>}
      </View>
    </Pressable>
  );
}

export default function Discover() {
  const [books, setBooks] = useState<Book[]>([]);
  const [filter, setFilter] = useState<Filter>("all");
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    setError("");
    try { setBooks(await listBooks()); }
    catch (e: any) { setError(e?.message || "تعذر الاتصال بالمكتبة"); }
    finally { setLoading(false); }
  }, []);
  useEffect(() => {
    load();
    const timer = setInterval(() => { load(); }, 5000);
    return () => clearInterval(timer);
  }, [load]);

  const shown = useMemo(() => books.filter(b => {
    if (filter === "audio" && !b.audio_available) return false;
    if (filter === "read" && !b.reading_available) return false;
    const needle = q.trim().toLowerCase();
    return !needle || b.title.toLowerCase().includes(needle) || (b.author || "").toLowerCase().includes(needle);
  }), [books, filter, q]);

  return (
    <View style={s.root}>
      <FlatList
        data={shown}
        keyExtractor={b => b.id}
        numColumns={2}
        columnWrapperStyle={s.row}
        contentContainerStyle={s.content}
        refreshControl={<RefreshControl refreshing={loading && books.length > 0} onRefresh={load} />}
        ListHeaderComponent={
          <View>
            <Text style={s.kicker}>كل العوالم في مكان واحد</Text>
            <Text style={s.title}>اكتشف</Text>
            <View style={s.search}><TextInput value={q} onChangeText={setQ} placeholder="إبحث عن عنوان أو مؤلف" placeholderTextColor="#B3A89D" style={s.searchInput}/><Ionicons name="search" size={27} color="#8F877F"/></View>
            <View style={s.filters}>
              {([['all','الكل'],['audio','صوت متاح'],['read','قراءة متاحة']] as [Filter,string][]).map(([key,label]) => (
                <Pressable key={key} onPress={() => setFilter(key)} style={[s.filter, filter === key && s.filterActive]}><Text style={[s.filterText,filter===key&&s.filterTextActive]}>{label}</Text></Pressable>
              ))}
            </View>
            <View style={s.sectionLine}><Text style={s.count}>{books.length} عمل</Text><Text style={s.section}>الأرشيف</Text></View>
            {!!error && <Pressable onPress={load} style={s.error}><Text style={s.errorText}>الخادم غير متصل: {error} — اضغط لإعادة المحاولة</Text></Pressable>}
            {loading && !books.length && <ActivityIndicator color={colors.gold} size="large" style={{marginVertical:35}}/>}
          </View>
        }
        renderItem={({item}) => <BookCard book={item}/>}
        ListEmptyComponent={!loading ? <Text style={s.empty}>جارٍ فهرسة مكتبتك من /storage/emulated/0/Z. اسحب للأسفل للتحديث.</Text> : null}
      />
    </View>
  );
}

const s = StyleSheet.create({
  root:{flex:1,backgroundColor:colors.bg},content:{paddingHorizontal:18,paddingTop:68,paddingBottom:110},
  kicker:{textAlign:"right",color:colors.muted,fontSize:16,marginBottom:9},title:{textAlign:"right",color:colors.ink,fontWeight:"900",fontSize:45,marginBottom:28},
  search:{height:62,borderRadius:21,backgroundColor:colors.card,flexDirection:"row-reverse",alignItems:"center",paddingHorizontal:18,gap:10},searchInput:{flex:1,textAlign:"right",fontSize:17,color:colors.ink},
  filters:{flexDirection:"row-reverse",gap:9,marginTop:18,marginBottom:42},filter:{paddingVertical:12,paddingHorizontal:18,borderRadius:24,borderWidth:1,borderColor:colors.line},filterActive:{backgroundColor:colors.dark,borderColor:colors.dark},filterText:{color:colors.muted,fontSize:14},filterTextActive:{color:colors.white},
  sectionLine:{flexDirection:"row",justifyContent:"space-between",alignItems:"center",marginBottom:20},section:{fontSize:27,fontWeight:"800",color:colors.ink},count:{fontSize:15,color:colors.gold},
  row:{justifyContent:"space-between"},cardWrap:{width:"47%",marginBottom:34},cover:{height:238,borderRadius:7,overflow:"hidden",backgroundColor:"#292827",padding:14,justifyContent:"space-between",borderWidth:1,borderColor:"#9A7850"},brand:{color:"#D9A66E",letterSpacing:4,fontWeight:"700",fontSize:12},circle:{position:"absolute",width:130,height:130,borderRadius:70,borderWidth:1.3,borderColor:"#95714E",right:-12,top:40},coverTitle:{textAlign:"right",color:"#FFF8EF",fontSize:21,lineHeight:31,fontWeight:"700",zIndex:2},coverFoot:{color:"#BEB6AC",fontSize:11},bookTitle:{textAlign:"right",fontSize:18,lineHeight:27,fontWeight:"700",color:colors.ink,marginTop:10},badges:{flexDirection:"row-reverse",gap:9,marginTop:7},badge:{flexDirection:"row-reverse",gap:4,alignItems:"center"},badgeText:{color:colors.muted,fontSize:12},
  error:{backgroundColor:"#F4DDD8",padding:12,borderRadius:12,marginBottom:16},errorText:{textAlign:"right",color:colors.danger},empty:{textAlign:"center",color:colors.muted,fontSize:16,lineHeight:27,marginTop:30}
});
