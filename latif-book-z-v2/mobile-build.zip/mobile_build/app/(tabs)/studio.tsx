import { useEffect, useState } from "react";
import { ActivityIndicator, Alert, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import * as DocumentPicker from "expo-document-picker";
import { getAdminToken, getApiBase, getSourceStatus, health, scanSourceNow, setAdminToken, setApiBase, uploadAssets } from "../../src/api";
import type { ImportResult } from "../../src/types";
import { colors } from "../../src/theme";

export default function Studio() {
  const [api, setApi] = useState("http://127.0.0.1:8765");
  const [token, setToken] = useState("");
  const [status, setStatus] = useState("جارٍ الاتصال…");
  const [source, setSource] = useState("/storage/emulated/0/Z");
  const [scan, setScan] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const [results, setResults] = useState<ImportResult[]>([]);

  async function refresh() {
    try {
      const h = await health();
      setStatus(`متصل · ${h.books} كتاب · ${h.audio} ملف صوتي`);
      const z = await getSourceStatus();
      setSource(z.source_root || "/storage/emulated/0/Z");
      setScan(z.scan || null);
    } catch (e:any) { setStatus(`غير متصل · ${e?.message || e}`); }
  }

  useEffect(() => { (async () => { setApi(await getApiBase()); setToken(await getAdminToken()); await refresh(); })(); const t=setInterval(refresh,4000); return()=>clearInterval(t); }, []);

  async function saveAndTest() {
    try { await setApiBase(api); await setAdminToken(token); await refresh(); }
    catch (e:any) { setStatus(`غير متصل · ${e?.message || e}`); }
  }

  async function rescanZ() {
    setBusy(true);
    try { await setApiBase(api); await setAdminToken(token); const r=await scanSourceNow(); setScan(r); await refresh(); Alert.alert("اكتمل الفحص", "تمت مزامنة محتوى Z مع المكتبة دون نقل أو نسخ ملفاتك."); }
    catch(e:any){ Alert.alert("تعذر الفحص", e?.message || String(e)); }
    finally{ setBusy(false); }
  }

  async function chooseFiles() {
    const picked = await DocumentPicker.getDocumentAsync({ type: "*/*", multiple: true, copyToCacheDirectory: true });
    if (picked.canceled) return;
    setBusy(true); setResults([]);
    try {
      await setApiBase(api); await setAdminToken(token);
      const res = await uploadAssets(picked.assets.map(a => ({ uri:a.uri, name:a.name, mimeType:a.mimeType })));
      setResults(res); await refresh();
    } catch (e:any) { Alert.alert("تعذر الاستيراد", e?.message || String(e)); }
    finally { setBusy(false); }
  }

  return <ScrollView style={s.root} contentContainerStyle={s.content}>
    <View style={s.top}><Text style={s.admin}>LATIF</Text><Text style={s.muted}>المكتبة المستقلة</Text></View>
    <Text style={s.kicker}>مصدر المحتوى المباشر</Text>
    <Text style={s.title}>مركز المكتبة</Text>
    <Text style={s.desc}>التطبيق لا يطلب منك نقل 20GB أو إعادة رفعها. الخادم يفهرس الكتب والأوديو مباشرة من مجلد Z ويبقي الملفات في مكانها.</Text>

    <View style={s.sourceCard}>
      <Ionicons name="folder-open" size={37} color={colors.goldSoft}/>
      <Text style={s.sourceLabel}>المسار الفعلي</Text>
      <Text selectable style={s.sourcePath}>{source}</Text>
      <Text style={s.sourceMeta}>{scan?.running ? "جارٍ الفحص الآن…" : `شوهد ${scan?.files_seen || 0} ملف · أضيف ${scan?.media_indexed || 0} عنصر في آخر فحص`}</Text>
      <Pressable onPress={rescanZ} disabled={busy} style={s.button}>{busy?<ActivityIndicator color={colors.dark}/>:<Text style={s.buttonText}>فحص Z الآن</Text>}</Pressable>
    </View>

    <Text style={s.status}>{status}</Text>

    <Text style={s.section}>إضافة ملف جديد خارج Z</Text>
    <Pressable onPress={chooseFiles} disabled={busy} style={s.secondary}><Text style={s.secondaryText}>اختيار ZIP / PDF / Audio</Text></Pressable>

    <Text style={s.section}>اتصال الخادم</Text>
    <TextInput value={api} onChangeText={setApi} autoCapitalize="none" style={s.input}/>
    <TextInput value={token} onChangeText={setToken} autoCapitalize="none" secureTextEntry style={s.input} placeholder="رمز الإدارة"/>
    <Pressable style={s.secondary} onPress={saveAndTest}><Text style={s.secondaryText}>حفظ وفحص الاتصال</Text></Pressable>

    {!!results.length && <View><Text style={s.section}>آخر استيراد</Text>{results.map((r,i)=><View style={s.result} key={`${r.source_name}-${i}`}><Text style={s.resultTitle}>{r.source_name}</Text><Text style={s.resultText}>{r.status} · {r.media_linked || 0} ملف مرتبط</Text></View>)}</View>}
  </ScrollView>;
}

const s=StyleSheet.create({root:{flex:1,backgroundColor:colors.bg},content:{padding:24,paddingTop:66,paddingBottom:130},top:{flexDirection:"row",justifyContent:"space-between",alignItems:"center"},admin:{backgroundColor:colors.dark,color:colors.goldSoft,paddingHorizontal:16,paddingVertical:11,borderRadius:8,letterSpacing:2},muted:{color:colors.muted,fontSize:15},kicker:{textAlign:"right",color:colors.gold,marginTop:38,fontSize:15},title:{textAlign:"right",fontSize:43,fontWeight:"900",color:colors.ink,marginTop:18},desc:{textAlign:"right",fontSize:16,lineHeight:29,color:colors.muted,marginTop:20},sourceCard:{backgroundColor:colors.dark,borderRadius:28,padding:28,alignItems:"center",marginTop:30},sourceLabel:{color:"#AAA19A",marginTop:12},sourcePath:{color:colors.white,fontSize:17,fontWeight:"800",marginTop:9,textAlign:"center"},sourceMeta:{color:"#AAA19A",marginTop:15,textAlign:"center"},button:{backgroundColor:colors.goldSoft,paddingHorizontal:30,paddingVertical:14,borderRadius:28,marginTop:22,minWidth:150,alignItems:"center"},buttonText:{fontWeight:"800",color:colors.dark},status:{textAlign:"right",marginTop:15,color:colors.muted},section:{textAlign:"right",fontSize:24,fontWeight:"850",color:colors.ink,marginTop:34,marginBottom:14},input:{backgroundColor:"#EFE8DE",borderWidth:1,borderColor:colors.line,borderRadius:14,padding:15,fontSize:15,textAlign:"left",marginBottom:10,color:colors.ink},secondary:{alignSelf:"stretch",borderWidth:1,borderColor:colors.gold,borderRadius:22,paddingHorizontal:20,paddingVertical:13,alignItems:"center"},secondaryText:{color:colors.gold,fontWeight:"700"},result:{padding:15,borderRadius:14,backgroundColor:"#EFE7DC",marginBottom:9},resultTitle:{textAlign:"right",fontWeight:"800",color:colors.ink},resultText:{textAlign:"right",color:colors.muted,marginTop:5}});
