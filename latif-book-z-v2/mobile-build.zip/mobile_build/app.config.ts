import type { ExpoConfig } from "expo/config";

const config: ExpoConfig = {
  name: "LATIF — Literary Audio",
  slug: "latif-literary-audio-independent",
  version: "2.0.0",
  orientation: "portrait",
  scheme: "latifliterary",
  userInterfaceStyle: "light",
  newArchEnabled: true,
  android: {
    package: "com.latif.literaryaudio",
    versionCode: 20000,
    edgeToEdgeEnabled: true,
    predictiveBackGestureEnabled: false
  },
  ios: {
    supportsTablet: true,
    bundleIdentifier: "com.latif.literaryaudio"
  },
  plugins: [
    "expo-router",
    [
      "expo-build-properties",
      { android: { usesCleartextTraffic: true, minSdkVersion: 24, compileSdkVersion: 36, targetSdkVersion: 36 } }
    ],
    [
      "expo-audio",
      {
        microphonePermission: false,
        recordAudioAndroid: false,
        enableBackgroundPlayback: true
      }
    ]
  ],
  experiments: { typedRoutes: true }
};

export default config;
