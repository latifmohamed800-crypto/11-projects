export const colors = {
  bg: "#F8F3EB",
  card: "#EFE7DC",
  ink: "#252326",
  muted: "#948A7E",
  gold: "#B17B42",
  goldSoft: "#DCA971",
  line: "#DDD1C1",
  dark: "#232124",
  white: "#FFFFFF",
  danger: "#9F3A38",
  ok: "#3D7657",
};
