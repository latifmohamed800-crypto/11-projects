export type MediaItem = {
  id: string;
  kind: "document" | "audio" | "video" | "cover";
  file_name: string;
  mime_type?: string | null;
  size_bytes: number;
  duration_seconds?: number | null;
  url: string;
};

export type Book = {
  id: string;
  title: string;
  author?: string | null;
  description?: string | null;
  reading_available: boolean;
  audio_available: boolean;
  cover_url?: string | null;
  media: MediaItem[];
  updated_at: string;
};

export type ImportResult = {
  import_id?: string;
  source_name: string;
  status: string;
  books_created?: number;
  media_linked?: number;
  rejected_files?: number;
  message?: string;
};
