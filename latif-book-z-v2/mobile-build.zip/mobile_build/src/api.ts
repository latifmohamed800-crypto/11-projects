import AsyncStorage from "@react-native-async-storage/async-storage";
import type { Book, ImportResult } from "./types";

const API_KEY = "latif.api.url";
const TOKEN_KEY = "latif.api.adminToken";
const CLIENT_KEY = "latif.client.id";
const DEFAULT_API = "http://127.0.0.1:8765";

export async function getApiBase() {
  const value = await AsyncStorage.getItem(API_KEY);
  return (value || DEFAULT_API).replace(/\/$/, "");
}

export async function setApiBase(value: string) {
  const clean = value.trim().replace(/\/$/, "");
  if (!/^https?:\/\//i.test(clean)) throw new Error("اكتب رابطاً يبدأ بـ http:// أو https://");
  await AsyncStorage.setItem(API_KEY, clean);
}

export async function getAdminToken() {
  return (await AsyncStorage.getItem(TOKEN_KEY)) || "";
}

export async function setAdminToken(value: string) {
  await AsyncStorage.setItem(TOKEN_KEY, value.trim());
}

export async function getClientId() {
  let id = await AsyncStorage.getItem(CLIENT_KEY);
  if (!id) {
    id = `android-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    await AsyncStorage.setItem(CLIENT_KEY, id);
  }
  return id;
}

async function request(path: string, init?: RequestInit) {
  const base = await getApiBase();
  const response = await fetch(`${base}${path}`, init);
  if (!response.ok) {
    let detail = `${response.status}`;
    try { detail = (await response.json()).detail || detail; } catch {}
    throw new Error(detail);
  }
  return response;
}

export async function health() {
  return (await request("/health")).json();
}


export async function getSourceStatus() {
  return (await request("/v1/source/status")).json();
}

export async function scanSourceNow() {
  const token = await getAdminToken();
  return (await request("/v1/source/scan", { method: "POST", headers: token ? { "X-Admin-Token": token } : undefined })).json();
}

export async function listBooks(): Promise<Book[]> {
  const data = await (await request("/v1/books")).json();
  return data.items || [];
}

export async function getBook(id: string): Promise<Book> {
  return (await (await request(`/v1/books/${encodeURIComponent(id)}`)).json()) as Book;
}

export async function uploadAssets(assets: Array<{ uri: string; name: string; mimeType?: string | null }>): Promise<ImportResult[]> {
  const base = await getApiBase();
  const token = await getAdminToken();
  const form = new FormData();
  for (const asset of assets) {
    form.append("files", {
      uri: asset.uri,
      name: asset.name,
      type: asset.mimeType || "application/octet-stream"
    } as any);
  }
  const res = await fetch(`${base}/v1/import`, {
    method: "POST",
    headers: token ? { "X-Admin-Token": token } : undefined,
    body: form
  });
  if (!res.ok) {
    let detail = `${res.status}`;
    try { detail = (await res.json()).detail || detail; } catch {}
    throw new Error(detail);
  }
  const payload = await res.json();
  return payload.results || [];
}

export async function saveProgress(bookId: string, mediaId: string | undefined, positionSeconds: number) {
  const clientId = await getClientId();
  await request(`/v1/books/${encodeURIComponent(bookId)}/progress`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ client_id: clientId, media_id: mediaId, position_seconds: Math.max(0, positionSeconds) })
  });
}

export async function getProgress(bookId: string) {
  const clientId = await getClientId();
  return (await (await request(`/v1/books/${encodeURIComponent(bookId)}/progress?client_id=${encodeURIComponent(clientId)}`)).json());
}
